# Tugas Besar 1 IF2210-OOP 2017

# YOGS!
Yu-gi-oh Simulator
# Deskripsi
Simluasi game yu gi-oh berbasis command line interface.
# Play
##Regulatory
##How-to
##Card included
# Human
Tugas Besar
  - Kukuh KR (18215030)
  - Condro Wiyono (18215042)
  - M Faisal Aziz (18215044)
