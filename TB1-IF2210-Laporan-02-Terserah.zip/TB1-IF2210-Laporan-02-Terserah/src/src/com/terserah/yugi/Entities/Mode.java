
package com.terserah.yugi.Entities;

/**
 *
 * @author condro
 */
public enum Mode {
	ATTACK,DEFENSE
}
