package com.terserah.yugi.Entities;

/**
 *
 * @author condro
 */
public enum Location {
	DECK, HAND, FIELD, GRAVEYARD
}
