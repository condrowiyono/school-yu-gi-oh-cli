package com.terserah.yugi.Entities;

/**
 *
 * @author muhfai
 */
public class Graveyard extends Field {
	private static int lastIdxEff = 0;
	
	public Graveyard() {
		
	}
}

