package com.terserah.yugi.Entities;

/**
 *
 * @author condro
 */
public enum Phase {
	MAIN1, BATTLE, MAIN2
}
